class CheckError(RuntimeError): pass

TRUSTED_INSTALLER_SID = 'S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464'

_FULL_WRITE_MASK = 0xD0156

_NAMESPACE_MASK = 0xD0150

_GENERIC_MASK = 0xF0000000

def _verify_acl_records(records, *, mailbox, system_drive, current_sid):
    """Pure policy over an exhaustive Windows ACL snapshot. No ACL changes.

    Creation-only relaxation and TrustedInstaller ownership apply ONLY to the
    exact system volume root. All other ancestors retain the original strict
    write mask. Inherit-only grants are checked on actual children, and at the
    mailbox as future child grants. Denies never erase a dangerous allow.
    """
    import ntpath
    def norm(value):
        if not isinstance(value, str) or not ntpath.isabs(value) or value.startswith('\\\\'):
            raise CheckError('Local absolute ACL path required')
        return ntpath.normcase(ntpath.normpath(value))
    if not isinstance(system_drive,str) or len(system_drive)!=2 or system_drive[1]!=':' or not system_drive[0].isalpha():
        raise CheckError('System drive not verified')
    root=norm(system_drive+'\\'); leaf=norm(mailbox)
    if not isinstance(current_sid,str) or not current_sid.startswith('S-1-'):
        raise CheckError('Current Windows SID unavailable')
    trusted={current_sid,'S-1-5-18','S-1-5-32-544'}
    expected=set(); cursor=leaf
    while True:
        expected.add(cursor); parent=ntpath.dirname(cursor)
        if parent==cursor: break
        cursor=parent
    seen=set()
    for record in records:
        path=norm(record['path'])
        if path in seen: raise CheckError('Duplicate ACL object')
        seen.add(path)
        is_chain=path in expected
        is_file=record.get('kind')=='file'
        if not is_chain and not (is_file and ntpath.dirname(path)==leaf):
            raise CheckError('Unexpected mailbox object')
        if is_chain and record.get('kind')!='directory': raise CheckError('Directory required')
        if record.get('reparse') is not False or record.get('null_dacl') is not False:
            raise CheckError('Reparse or null DACL rejected')
        owner=record.get('owner')
        if owner not in trusted and not (path==root and owner==TRUSTED_INSTALLER_SID):
            raise CheckError('Owner rejected')
        rules=record.get('rules')
        if not isinstance(rules,list): raise CheckError('DACL unavailable')
        for rule in rules:
            if rule.get('type') not in ('Allow','Deny'): raise CheckError('Unsupported ACE')
            if rule['type']=='Deny': continue
            sid=rule.get('sid'); rights=rule.get('rights')
            io=rule.get('inherit_only'); flags=rule.get('inheritance')
            if type(rights) is not int or not 0<=rights<=0xFFFFFFFF or type(io) is not bool or type(flags) is not int or flags not in (0,1,2,3):
                raise CheckError('Malformed ACE')
            if rights & _GENERIC_MASK: raise CheckError('Unexpanded generic ACE')
            if sid in trusted: continue
            if io:
                # On ancestors this has no current access effect. Every actual
                # child is independently examined; mailbox child templates must
                # also stay safe for files created after this snapshot.
                if path!=leaf: continue
                if sid=='S-1-3-0' and flags:
                    # CREATOR OWNER resolves to the trusted creating identity;
                    # effective untrusted creation rights are separately denied.
                    continue
                if flags and rights & _FULL_WRITE_MASK:
                    raise CheckError('Unsafe future mailbox child ACE')
                continue
            mask=_NAMESPACE_MASK if path==root else _FULL_WRITE_MASK
            if rights & mask: raise CheckError('Untrusted effective writer')
    if not expected.issubset(seen): raise CheckError('Incomplete ancestor ACL snapshot')
