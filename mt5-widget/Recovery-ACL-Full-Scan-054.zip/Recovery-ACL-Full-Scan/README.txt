READ-ONLY RECOVERY ACL FULL SCAN
Unzip, double-click CHECK_ALL_ACL.cmd. Python 3 and Windows PowerShell are required.
No installation, permissions change, MT5 import, trading, network or saved report.
The console pauses for a screenshot. Local paths, usernames, SIDs and account IDs
are not printed. Object role/depth/index and rule index allow error comparison.

This scans discovered RECOVERY mailboxes under APPDATA/MetaQuotes/Terminal,
their existing ancestors and immediate mailbox items. Unexpected directories
are reported and are NOT traversed. Failed object ACL reads are reported while
other objects continue. Top-level discovery/collector failures are fixed codes.

Policy054.py contains the exact pure policy from installer-054-work, unchanged.
GENERIC_ACE remains an installer failure. The diagnostic additionally expands
Windows FILE generic rights and evaluates the SAME strict policy on that mapped
rule. This does not authorize launching or alter installed software.
Mappings: GENERIC_READ=0x120089, WRITE=0x120116, EXECUTE=0x1200A0,
ALL=0x1F01FF. Specific original bits are preserved. Generic write/all remain
subject to write/namespace masks, owner and inheritance checks.
Sources:
https://learn.microsoft.com/en-us/windows/win32/fileio/file-security-and-access-rights
https://learn.microsoft.com/en-us/windows/win32/fileio/file-access-rights-constants

Synthetic tests run on Linux; actual PowerShell/Windows execution is not verified.
This is a moment-in-time ACL diagnostic, not a proof against concurrent ACL
changes or a test of EA, broker execution or application readiness.
