$ErrorActionPreference='Stop'; [Console]::OutputEncoding=[Text.UTF8Encoding]::new($false);
function Read-Node($item){ try {
 $a=Get-Acl -LiteralPath $item.FullName;
 $raw=[Security.AccessControl.RawSecurityDescriptor]::new($a.GetSecurityDescriptorBinaryForm(),0);
 $rules=@(); $unsupported=$false;
 if($null -ne $raw.DiscretionaryAcl){foreach($ace in $raw.DiscretionaryAcl){if($ace.AceType -notin @([Security.AccessControl.AceType]::AccessAllowed,[Security.AccessControl.AceType]::AccessDenied)){$unsupported=$true}}};
 foreach($r in $a.Access){$rules+=@{type=$r.AccessControlType.ToString();sid=$r.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value;rights=([long]$r.FileSystemRights -band 4294967295);inherit_only=(($r.PropagationFlags -band [Security.AccessControl.PropagationFlags]::InheritOnly) -ne 0);inheritance=[int]$r.InheritanceFlags}};
 return @{unsupported_raw=$unsupported;path=$item.FullName;kind=$(if($item -is [IO.DirectoryInfo]){'directory'}else{'file'});owner=([Security.Principal.NTAccount]$a.Owner).Translate([Security.Principal.SecurityIdentifier]).Value;reparse=(($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0);null_dacl=($null -eq $raw.DiscretionaryAcl);rules=@($rules)}
} catch { return @{path=$item.FullName;collection_error=$true} } };
$p=$env:RECOVERY_CHECK_MAILBOX; $leaf=Get-Item -LiteralPath $p -Force; $records=@(); $cursor=$leaf;
while($null -ne $cursor){$records+=Read-Node $cursor; $cursor=$cursor.Parent};
foreach($child in @(Get-ChildItem -LiteralPath $p -Force)){$records+=Read-Node $child};
@{current_sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value;system_drive=[IO.Path]::GetPathRoot([Environment]::SystemDirectory).TrimEnd('\');records=@($records)} | ConvertTo-Json -Depth 8 -Compress
