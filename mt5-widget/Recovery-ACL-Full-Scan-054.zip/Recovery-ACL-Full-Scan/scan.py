"""Offline ACL diagnostic only. Does not approve or launch native runtime."""
import copy
import json
import ntpath
import os
from pathlib import Path
import subprocess
import policy054 as policy

# FILE_GENERIC_* and FILE_ALL_ACCESS, not registry/service mappings.
GENERIC = {0x80000000:0x120089,0x40000000:0x120116,
           0x20000000:0x1200A0,0x10000000:0x1F01FF}
def expand_file_generic(mask):
    result=mask & 0x0FFFFFFF
    for generic,specific in GENERIC.items():
        if mask & generic: result |= specific
    return result

def analyze(data,mailbox):
    norm=lambda p:ntpath.normcase(ntpath.normpath(p))
    leaf=norm(mailbox);root=norm(data['system_drive']+'\\');expected=[];cursor=leaf
    while True:
        expected.append(cursor);parent=ntpath.dirname(cursor)
        if parent==cursor:break
        cursor=parent
    me=data['current_sid']; records=data['records'];results=[]
    skeleton=[dict(path=p,kind='directory',owner=me,reparse=False,null_dacl=False,rules=[]) for p in expected]
    def verdict(rows):
        try:policy._verify_acl_records(rows,mailbox=mailbox,system_drive=data['system_drive'],current_sid=me);return 'PASS'
        except policy.CheckError as e:return str(e)
    if verdict(skeleton)!='PASS':return [dict(code='INVALID_CONTEXT')]
    seen=set()
    for index,r in enumerate(records,1):
        path=norm(r.get('path',''));role='MAILBOX' if path==leaf else 'SYSTEM_ROOT' if path==root else 'ANCESTOR' if path in expected else 'MAILBOX_ITEM'
        context=dict(object=index,role=role,depth=expected.index(path) if path in expected else -1)
        def emit(code,**kw):results.append(dict(context,code=code,**kw))
        if path in seen:emit('DUPLICATE_OBJECT')
        seen.add(path)
        if r.get('collection_error'):emit('ACL_READ_ERROR');continue
        if r.get('unsupported_raw'):emit('UNSUPPORTED_RAW_ACE')
        clean=copy.deepcopy(r);clean['rules']=[]
        trial=[x for x in skeleton if norm(x['path'])!=path]+[clean]
        status=verdict(trial)
        if status!='PASS':emit('OBJECT_POLICY',detail=status)
        # Independently test EVERY rule, so one owner or ACE error cannot hide others.
        rules=r.get('rules')
        if not isinstance(rules,list):emit('DACL_UNAVAILABLE');continue
        for n,rule in enumerate(rules,1):
            obj=dict(clean,owner=me,reparse=False,null_dacl=False,rules=[rule])
            rows=[x for x in skeleton if norm(x['path'])!=path]+[obj]
            status=verdict(rows)
            sid=rule.get('sid'); trustee='CURRENT' if sid==me else 'SYSTEM' if sid=='S-1-5-18' else 'ADMINISTRATORS' if sid=='S-1-5-32-544' else 'CREATOR_OWNER' if sid=='S-1-3-0' else 'OTHER'
            rights=rule.get('rights'); fields=dict(rule=n,trustee=trustee,inherit_only=rule.get('inherit_only'),inheritance=rule.get('inheritance'),ace_type=rule.get('type'))
            if type(rights) is int and 0<=rights<=0xFFFFFFFF:
                fields['mask']='0x%08X'%rights
                if rights&0xF0000000:
                    mapped=expand_file_generic(rights);obj['rules']=[dict(rule,rights=mapped)]
                    fields.update(mapped_mask='0x%08X'%mapped,mapped_policy=verdict(rows))
                    emit('GENERIC_ACE',current_policy=status,**fields)
                    continue
            emit('RULE_OK' if status=='PASS' else 'RULE_POLICY',detail=status,**fields)
    for missing in set(expected)-seen:
        results.append(dict(code='MISSING_OBJECT',role='MAILBOX' if missing==leaf else 'SYSTEM_ROOT' if missing==root else 'ANCESTOR',depth=expected.index(missing)))
    return results

def main():
    print('RECOVERY ACL FULL SCAN / READ ONLY / NOT A TRADING APPROVAL')
    print('Generic mapping is diagnostic only; installer policy remains unchanged.')
    if os.name!='nt':print('STATUS=WINDOWS_REQUIRED');return
    try:
        found=sorted((Path(os.environ['APPDATA'])/'MetaQuotes'/'Terminal').glob('*/MQL5/Files/RECOVERY'))
        if not found:print('STATUS=MAILBOX_NOT_FOUND')
        for i,p in enumerate(found,1):
            print('MAILBOX_INDEX='+str(i))
            try:
                chain=list(reversed([p,*p.parents]))
                if any(getattr(node.lstat(),'st_file_attributes',0)&1024 for node in chain):
                    print('STATUS=REPARSE_PATH_NOT_SCANNED');continue
                env=os.environ.copy();env['RECOVERY_CHECK_MAILBOX']=str(p)
                script=Path(__file__).with_name('collector.ps1').read_text(encoding='utf-8')
                r=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',script],env=env,capture_output=True,encoding='utf-8',errors='strict',timeout=60,creationflags=subprocess.CREATE_NO_WINDOW)
                if r.returncode:print('STATUS=COLLECTOR_FAILED');continue
                report=analyze(json.loads(r.stdout),str(p))
                findings=[row for row in report if row['code']!='RULE_OK' and not (row['code']=='GENERIC_ACE' and row['mapped_policy']=='PASS')]
                print('GENERIC_WITHOUT_BLOCK='+str(sum(row['code']=='GENERIC_ACE' and row['mapped_policy']=='PASS' for row in report)))
                for row in findings:print(json.dumps(row,ensure_ascii=True))
                print('FINDINGS='+str(len(findings)))
                print('STATUS=SCAN_COMPLETE_NO_RUNTIME_AUTHORIZATION')
            except Exception:print('STATUS=COLLECTION_OR_FORMAT_FAILED')
    except Exception:print('STATUS=DISCOVERY_FAILED')
if __name__=='__main__':main()
