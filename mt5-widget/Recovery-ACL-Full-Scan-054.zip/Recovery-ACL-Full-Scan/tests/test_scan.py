import unittest
import scan
from policy054 import TRUSTED_INSTALLER_SID
class Tests(unittest.TestCase):
 def fixture(self):
  def obj(p):return dict(path=p,kind='directory',owner='S-1-5-21-1',reparse=False,null_dacl=False,rules=[])
  return dict(system_drive='C:',current_sid='S-1-5-21-1',records=[obj('C:\\'),obj('C:\\RECOVERY')])
 def rule(self,mask):return dict(type='Allow',sid='S-1-5-32-545',rights=mask,inherit_only=False,inheritance=0)
 def test_mapping(self):
  for a,b in scan.GENERIC.items():self.assertEqual(scan.expand_file_generic(a),b)
  self.assertEqual(scan.expand_file_generic(0xC0000040),0x1201DF)
 def test_read_generic_diagnostic_not_bypass(self):
  d=self.fixture();d['records'][0]['rules']=[self.rule(0x80000000)]
  r=scan.analyze(d,'C:\\RECOVERY')[0]
  self.assertEqual(r['code'],'GENERIC_ACE');self.assertEqual(r['mapped_policy'],'PASS');self.assertNotEqual(r['current_policy'],'PASS')
 def test_write_generic_stays_rejected(self):
  d=self.fixture();d['records'][1]['rules']=[self.rule(0x40000000)]
  self.assertNotEqual(scan.analyze(d,'C:\\RECOVERY')[0]['mapped_policy'],'PASS')
 def test_all_errors_no_path_or_sid(self):
  d=self.fixture();d['records'][1]['owner']='S-1-5-21-999';d['records'][1]['rules']=[self.rule(2),self.rule(0x40)]
  r=scan.analyze(d,'C:\\RECOVERY');self.assertEqual(len(r),3)
  self.assertNotIn('C:',str(r));self.assertNotIn('S-1-',str(r))
 def test_read_error_keeps_other_objects(self):
  d=self.fixture();d['records'][0]['collection_error']=True;d['records'][1]['rules']=[self.rule(2)]
  self.assertEqual(len(scan.analyze(d,'C:\\RECOVERY')),2)
 def test_root_owner_and_missing(self):
  d=self.fixture();d['records'][0]['owner']=TRUSTED_INSTALLER_SID
  self.assertEqual(scan.analyze(d,'C:\\RECOVERY'),[])
  d['records'].pop(0);self.assertEqual(scan.analyze(d,'C:\\RECOVERY')[0]['code'],'MISSING_OBJECT')
if __name__=='__main__':unittest.main()
