from pathlib import Path
import queue
import threading
import tkinter as tk
from tkinter import messagebox
from smoke_core import Session
root=tk.Tk();root.title('RECOVERY: отдельный HTTPS тест, без торговли');root.geometry('900x700')
box=tk.Frame(root,padx=12,pady=12);box.pack(fill='both',expand=True)
tk.Label(box,text='Публичный IPv4 вашего VPS:',font=('Segoe UI',12)).pack(anchor='w');entry=tk.Entry(box,width=35);entry.pack(anchor='w')
tk.Label(box,justify='left',wraplength=850,text='Только статическая страница /health. MT5 и торговый сервис не используются.\nНужен доступ из интернета к TCP 443 и исходящий HTTPS к Let’s Encrypt. Порт 80 не используется.\nFirewall/порты/службы помощник не меняет. Если Windows спросит доступ сети, решите отдельно.\nНе запускайте при уже работающем сервере на 443. Другие процессы помощник не останавливает.').pack(anchor='w',pady=10)
status=tk.StringVar(value='Введите IP. Проверка IP не доказывает, что он принадлежит этому VPS.')
tk.Label(box,textvariable=status,wraplength=850,justify='left').pack(anchor='w')
buttons=tk.Frame(box);buttons.pack(fill='x',pady=10)
log=tk.Text(box,wrap='word');log.pack(fill='both',expand=True)
session=Session(Path.home()/'Recovery-Server'/'tools'/'caddy'/'caddy.exe');events=queue.Queue();busy=[False]
def start():
    if busy[0] or session.proc is not None:return
    ip=entry.get().strip()
    if not messagebox.askyesno('Запустить временный HTTPS тест?', 'Подтверждаете, что IP принадлежит вашему VPS?\n\nCaddy займёт TCP 443, передаст IP в Let’s Encrypt и запросит публичный сертификат (IP попадёт в публичные CT-журналы).\nУсловия Let’s Encrypt: https://letsencrypt.org/repository/\n\nПродолжить с этими условиями? Никаких ордеров/MT5.'):return
    busy[0]=True;start_button.config(state='disabled');status.set('Проверяю Caddy и запускаю только тестовый процесс…')
    def work():
        try:events.put(('started',session.start(ip)))
        except Exception as exc:events.put(('error',str(exc)))
    threading.Thread(target=work,daemon=False).start()
def stop():
    if busy[0]:return
    busy[0]=True;stop_button.config(state='disabled')
    def work():
        try:session.stop();events.put(('stopped','Тест остановлен. Временные сертификаты/конфиг удалены.'))
        except Exception:events.put(('error','Не удалось подтвердить остановку. Проверьте процесс вручную.'))
    threading.Thread(target=work,daemon=False).start()
start_button=tk.Button(buttons,text='Запустить HTTPS тест',command=start);start_button.pack(side='left')
stop_button=tk.Button(buttons,text='Остановить тест',command=stop,state='disabled');stop_button.pack(side='left',padx=10)
def poll():
    while True:
        try:kind,text=events.get_nowait()
        except queue.Empty:break
        busy[0]=False
        if kind=='started':
            status.set('Процесс запущен, сертификат ещё НЕ подтверждён.\nНа телефоне через мобильный интернет откройте '+text+'\nДолжно быть RECOVERY_HTTPS_SMOKE_ONLY_OK без предупреждений TLS.');stop_button.config(state='normal')
        else:status.set(text);start_button.config(state='normal')
    if not busy[0] and session.proc is not None:
        log.delete('1.0','end');log.insert('end',session.logs());log.see('end')
        if session.proc.poll() is not None:status.set('Caddy завершился. Посмотрите журнал, затем нажмите «Остановить тест». Это не успешная проверка HTTPS.')
    root.after(500,poll)
def close():
    if busy[0] or session.proc is not None:messagebox.showinfo('Сначала остановите тест','Нажмите «Остановить тест» и дождитесь результата.')
    else:root.destroy()
root.protocol('WM_DELETE_WINDOW',close);root.after(500,poll);root.mainloop()
