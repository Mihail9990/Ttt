@echo off
setlocal DisableDelayedExpansion
"%USERPROFILE%\Recovery-Server\.venv-native\Scripts\pythonw.exe" "%~dp0smoke_gui.pyw"
if errorlevel 1 pause
