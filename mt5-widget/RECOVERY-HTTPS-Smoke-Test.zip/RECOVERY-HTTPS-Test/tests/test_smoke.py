import json
from pathlib import Path
import tempfile
from types import SimpleNamespace as N
from unittest.mock import patch
import unittest
import smoke_core as s
class Child:
    def __init__(self):self.terminated=False
    def poll(self):return 0 if self.terminated else None
    def terminate(self):self.terminated=True
    def wait(self,timeout):return 0
    def kill(self):self.terminated=True
class Tests(unittest.TestCase):
    def test_ip(self):
        self.assertEqual(s.public_ip('8.8.8.8'),'8.8.8.8')
        for ip in ['127.0.0.1','192.168.1.2','100.64.0.1','203.0.113.1','224.0.0.1','0.0.0.0','::1','8.8.8.8 {']:
            with self.assertRaises(Exception):s.public_ip(ip)
    def test_config_is_static_443_only(self):
        c=s.config('8.8.8.8',Path('/tmp/test storage'))
        for expected in ['admin off','persist_config off','disable_redirects','disable_http_challenge','profile shortlived','protocols h1 h2','/health','SMOKE_TEST_ONLY_NO_API']:
            self.assertIn(expected,c)
        for absent in ['reverse_proxy','8767','2019','tls internal','http://','file_server']:
            self.assertNotIn(absent,c)
    def test_start_stop_owns_only_child(self):
        with tempfile.TemporaryDirectory() as d:
            exe=Path(d)/'caddy.exe';exe.write_bytes(b'fixture');child=Child();commands=[]
            def run(args,**kw):
                self.assertFalse(kw['shell']);commands.append(args)
                return N(returncode=0,stdout='v2.11.9 fixture' if args[1]=='version' else json.dumps({'admin':{'disabled':True}}))
            def popen(args,**kw):commands.append(args);self.assertFalse(kw['shell']);return child
            with patch.object(s,'EXE_SHA256',s.hashlib.sha256(b'fixture').hexdigest()):
                ses=s.Session(exe,run=run,popen=popen);self.assertEqual(ses.start('8.8.8.8'),'https://8.8.8.8/health')
                temp=ses.temp.name;ses.stop()
            self.assertTrue(child.terminated);self.assertFalse(Path(temp).exists())
            self.assertEqual([c[1] for c in commands],['version','adapt','validate','run'])
    def test_bad_hash_never_execute(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'caddy.exe';p.write_bytes(b'wrong')
            with self.assertRaises(s.SmokeError):s.Session(p,run=lambda *a,**k:self.fail('executed')).start('8.8.8.8')
    def test_validate_failure_never_run(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'caddy.exe';p.write_bytes(b'x')
            def run(args,**kw):return N(returncode=1,stdout='')
            with patch.object(s,'EXE_SHA256',s.hashlib.sha256(b'x').hexdigest()):
                ses=s.Session(p,run=run,popen=lambda *a,**k:self.fail('started'))
                with self.assertRaises(s.SmokeError):ses.start('8.8.8.8')
                self.assertIsNone(ses.temp)
if __name__=='__main__':unittest.main()
