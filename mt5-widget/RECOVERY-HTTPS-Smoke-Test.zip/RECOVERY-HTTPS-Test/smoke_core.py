import hashlib
import ipaddress
import json
import os
from pathlib import Path
import subprocess
import tempfile

EXE_SHA256='2622e239c79df700b0eb92cbd950d1edee365e155a7859f358f0e55f002df591'
CA='https://acme-v02.api.letsencrypt.org/directory'
class SmokeError(RuntimeError):pass

def public_ip(value):
    ip=ipaddress.IPv4Address(value.strip())
    if not ip.is_global or ip.is_multicast or ip.is_reserved:raise SmokeError('Нужен публичный IPv4 вашего VPS.')
    return str(ip)

def config(ip, storage):
    ip=public_ip(ip)
    path=json.dumps(str(Path(storage).absolute()).replace('\\','/'))
    return '''{
    admin off
    persist_config off
    skip_install_trust
    auto_https disable_redirects
    storage file_system {
        root %s
    }
    servers {
        protocols h1 h2
    }
}
https://%s {
    tls {
        issuer acme {
            dir %s
            profile shortlived
            disable_http_challenge
        }
    }
    handle /health {
        header Content-Type text/plain
        respond "RECOVERY_HTTPS_SMOKE_ONLY_OK" 200
    }
    handle {
        respond "SMOKE_TEST_ONLY_NO_API" 404
    }
}
'''%(path,ip,CA)

class Session:
    def __init__(self,exe,*,run=subprocess.run,popen=subprocess.Popen):
        self.exe=Path(exe);self.run=run;self.popen=popen;self.proc=None;self.temp=None;self.log=None
    def start(self,ip):
        if self.proc is not None:raise SmokeError('Этот тест уже запущен.')
        ip=public_ip(ip)
        if self.exe.is_symlink() or not self.exe.is_file():raise SmokeError('Не найден проверенный caddy.exe.')
        if hashlib.sha256(self.exe.read_bytes()).hexdigest()!=EXE_SHA256:raise SmokeError('SHA256 caddy.exe отличается от официального v2.11.9.')
        self.temp=tempfile.TemporaryDirectory(prefix='recovery-https-smoke-')
        folder=Path(self.temp.name);path=folder/'Caddyfile'
        path.write_text(config(ip,folder/'certificates'),encoding='utf-8')
        flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
        try:
            for args in ([str(self.exe),'version'],[str(self.exe),'adapt','--config',str(path),'--adapter','caddyfile']):
                r=self.run(args,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=20,creationflags=flags,shell=False)
                if r.returncode:raise SmokeError('Caddy не прошёл проверку версии/синтаксиса.')
                if args[1]=='version' and not r.stdout.startswith('v2.11.9 '):raise SmokeError('Нужен Caddy v2.11.9.')
                if args[1]=='adapt':
                    data=json.loads(r.stdout)
                    if data.get('admin',{}).get('disabled') is not True:raise SmokeError('Admin API не отключён.')
            # validate provisions configuration without starting listeners; no run until explicit operator consent.
            r=self.run([str(self.exe),'validate','--config',str(path),'--adapter','caddyfile'],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=30,creationflags=flags,shell=False)
            if r.returncode:raise SmokeError('Конфигурация Caddy не прошла validate.')
            self.log=(folder/'caddy.log').open('w',encoding='utf-8')
            self.proc=self.popen([str(self.exe),'run','--config',str(path),'--adapter','caddyfile'],stdout=self.log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,creationflags=flags,shell=False,cwd=folder)
            return f'https://{ip}/health'
        except BaseException:
            self.stop();raise
    def logs(self):
        if not self.temp:return ''
        p=Path(self.temp.name)/'caddy.log'
        if not p.exists():return ''
        with p.open('rb') as f:
            f.seek(max(0,p.stat().st_size-30000))
            return f.read().decode('utf-8','replace')
    def stop(self):
        # Never caddy stop, taskkill, or lookup by process name: only our exact child handle.
        if self.proc is not None:
            if self.proc.poll() is None:
                self.proc.terminate()
                try:self.proc.wait(timeout=10)
                except subprocess.TimeoutExpired:self.proc.kill();self.proc.wait(timeout=5)
            self.proc=None
        if self.log:self.log.close();self.log=None
        if self.temp:
            self.temp.cleanup();self.temp=None
