"""Double-click preparation GUI. No live activation capability."""
import os
import queue
import sys
import threading
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from setup_core import install, prepare_ea, install_caddy


def main():
    root = tk.Tk()
    root.title('RECOVERY — подготовка Windows VPS (без торговли)')
    root.geometry('820x650')
    base = Path(__file__).resolve().parent
    payload = base / 'server'
    py = tk.StringVar(value=sys.executable)
    destination = tk.StringVar(value=str(Path.home() / 'Recovery-Server'))
    data_dir = tk.StringVar()
    events = queue.Queue()
    installed = [None]
    busy = [False]
    ttk.Label(root, text='Этот помощник только копирует server и устанавливает зависимости.\nНе запускает торговлю, MT5 или Caddy. Не меняет firewall и службы.', padding=10).pack(anchor='w')
    form = ttk.Frame(root, padding=10); form.pack(fill='x')
    def row(title, variable, choose):
        frame = ttk.Frame(form); frame.pack(fill='x', pady=4)
        ttk.Label(frame, text=title, width=24).pack(side='left')
        ttk.Entry(frame, textvariable=variable).pack(side='left', fill='x', expand=True)
        ttk.Button(frame, text='Выбрать', command=choose).pack(side='right')
    def choose_python():
        path = filedialog.askopenfilename(title='Python x64 — python.exe', filetypes=[('Python', 'python.exe'), ('Все файлы', '*.*')])
        if path: py.set(path)
    def choose_target():
        path = filedialog.askdirectory(title='Выберите родительскую папку; будет создана Recovery-Server')
        if path: destination.set(str(Path(path) / 'Recovery-Server'))
    def choose_data():
        path = filedialog.askdirectory(title='MT5 → Файл → Открыть каталог данных: выберите этот каталог')
        if path: data_dir.set(path)
    row('Python (64 bit):', py, choose_python)
    row('Новая папка установки:', destination, choose_target)
    row('Каталог данных MT5:', data_dir, choose_data)
    ttk.Label(form, text='Каталог MT5 необязателен. Его выбор не подключает счёт.\nCaddy можно установить кнопкой 3. Он не будет запущен; IP пока не нужен.').pack(anchor='w', pady=5)
    output = tk.Text(root, wrap='word', height=21); output.pack(fill='both', expand=True, padx=10)
    controls = ttk.Frame(root, padding=10); controls.pack(fill='x')
    def emit(value): events.put(('log', value))
    def start():
        if busy[0]: return
        p, t = py.get().strip(), destination.get().strip()
        if not messagebox.askyesno('Подготовить?', 'Будет создана НОВАЯ папка server и установлен набор Python-зависимостей из PyPI.\nТорговля не запускается. Продолжить?'): return
        busy[0] = True; start_button.config(state='disabled'); ea_button.config(state='disabled'); caddy_button.config(state='disabled')
        def work():
            try:
                path = install(payload, t, p, log=emit)
                events.put(('done', path))
            except Exception as exc: events.put(('error', str(exc)))
        threading.Thread(target=work, daemon=False).start()
    def ea():
        if busy[0] or installed[0] is None: return
        if not data_dir.get().strip(): choose_data()
        if not data_dir.get().strip(): return
        if not messagebox.askyesno('Подготовить исходник EA?', 'Скопировать только RecoveryEvidenceBridge.mq5 в выбранный каталог MT5?\nКомпиляция, добавление на график и Algo Trading не выполняются.'): return
        try:
            path = prepare_ea(installed[0], data_dir.get().strip())
            emit(f'Исходник EA скопирован: {path}\nОткройте его в MetaEditor и проверьте компиляцию вручную. EA не запущен.\n')
        except Exception as exc: messagebox.showerror('Не выполнено', str(exc))
    start_button = ttk.Button(controls, text='1. Подготовить сервер', command=start); start_button.pack(side='left')
    ea_button = ttk.Button(controls, text='2. Скопировать исходник EA', command=ea, state='disabled'); ea_button.pack(side='left', padx=8)
    def caddy():
        if busy[0] or installed[0] is None: return
        if not messagebox.askyesno('Установить Caddy?', 'Загрузить официальный Caddy 2.11.9 и проверить SHA256?\nОн будет сохранён в tools\\caddy новой установки, без запуска и изменения существующего Caddy.'): return
        busy[0] = True; ea_button.config(state='disabled'); caddy_button.config(state='disabled')
        def work():
            try:
                install_caddy(installed[0], log=emit)
                events.put(('caddy_done', None))
            except Exception as exc: events.put(('caddy_error', str(exc)))
        threading.Thread(target=work, daemon=False).start()
    caddy_button = ttk.Button(controls, text='3. Установить Caddy', command=caddy, state='disabled'); caddy_button.pack(side='left')
    def poll():
        while True:
            try: kind, value = events.get_nowait()
            except queue.Empty: break
            if kind == 'log': output.insert('end', value); output.see('end')
            else:
                busy[0] = False
                if kind in ('caddy_done', 'caddy_error'):
                    ea_button.config(state='normal'); caddy_button.config(state='normal')
                    if kind == 'caddy_error':
                        output.insert('end', '\nCaddy не установлен: '+value+'\nМожно повторить кнопкой 3.\n')
                        messagebox.showerror('Caddy: установка остановлена', value)
                elif kind == 'done':
                    installed[0] = value; ea_button.config(state='normal'); caddy_button.config(state='normal')
                    output.insert('end', '\nПодготовка завершена. Реальная торговля не запущена.\n')
                else:
                    output.insert('end', '\nОШИБКА: '+value+'\n'); start_button.config(state='normal')
                    messagebox.showerror('Подготовка остановлена', value)
        root.after(100, poll)
    def close():
        if busy[0]:
            messagebox.showinfo('Подождите', 'Дождитесь завершения установки. Закрытие окна не используется для прерывания pip.')
        else: root.destroy()
    root.protocol('WM_DELETE_WINDOW', close)
    root.after(100, poll)
    root.mainloop()

if __name__ == '__main__': main()
