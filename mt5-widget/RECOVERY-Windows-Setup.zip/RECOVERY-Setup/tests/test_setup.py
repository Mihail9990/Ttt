import io
import hashlib
from pathlib import Path
import tempfile
import unittest
import zipfile
from types import SimpleNamespace
from unittest.mock import patch
import setup_core as s

class SetupTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.root=Path(self.tmp.name)
        self.payload=self.root/'payload'; self.payload.mkdir()
        (self.payload/'requirements.txt').write_text('fastapi')
        (self.payload/'run_recovery_native.py').write_text('# no execution')
        self.python=self.root/'python.exe'; self.python.touch()
    def tearDown(self): self.tmp.cleanup()
    def test_existing_not_modified(self):
        dst=self.root/'server'; dst.mkdir(); (dst/'state.db').write_text('precious')
        with self.assertRaises(s.SetupError): s.copy_server(self.payload,dst)
        self.assertEqual((dst/'state.db').read_text(),'precious')
    def test_install_command_contract(self):
        calls=[]
        def runner(args,**kw):
            self.assertFalse(kw['shell']); calls.append(args)
            if args[1:3]==['-m','venv']: Path(args[-1]).mkdir()
            return SimpleNamespace(returncode=0,stdout='OK',stderr='')
        dst=s.install(self.payload,self.root/'server',self.python,log=lambda _:None,runner=runner,platform='nt')
        self.assertTrue((dst/'.venv-native/installed-versions.txt').exists())
        joined=' '.join(' '.join(c) for c in calls)
        self.assertIn('--only-binary=:all:',joined)
        for forbidden in ('order_send(', 'initialize(', 'Start-Native', 'firewall', 'ExecutionPolicy'):
            self.assertNotIn(forbidden,joined)
    def test_bad_python_no_copy(self):
        with self.assertRaises(s.SetupError):
            s.install(self.payload,self.root/'server',self.python,log=lambda _:None,platform='nt',runner=lambda *a,**k:SimpleNamespace(returncode=1,stdout='',stderr='bad'))
        self.assertFalse((self.root/'server').exists())
    def test_ea_never_overwrites(self):
        src=self.payload/'recovery/mql5'; src.mkdir(parents=True); (src/'RecoveryEvidenceBridge.mq5').write_text('source')
        data=self.root/'terminal'; (data/'MQL5/Experts').mkdir(parents=True)
        p=s.prepare_ea(self.payload,data); self.assertEqual(p.read_text(),'source')
        with self.assertRaises(s.SetupError): s.prepare_ea(self.payload,data)
    def archive(self):
        b=io.BytesIO()
        with zipfile.ZipFile(b,'w') as z:
            z.writestr('caddy.exe',b'MZsafe fixture'); z.writestr('../evil',b'ignored')
        return b.getvalue()
    def test_caddy_hash_and_exclusive(self):
        raw=self.archive(); server=self.root/'server'; server.mkdir()
        with patch.object(s,'CADDY_SHA256',hashlib.sha256(raw).hexdigest()):
            target=s.install_caddy(server,log=lambda _:None,opener=lambda *a,**k:io.BytesIO(raw))
        self.assertEqual(target.read_bytes(),b'MZsafe fixture'); self.assertFalse((server/'tools/evil').exists())
        with self.assertRaises(s.SetupError): s.install_caddy(server,log=lambda _:None)
    def test_caddy_checksum_failure_then_retry(self):
        raw=self.archive(); server=self.root/'server'; server.mkdir()
        with self.assertRaises(s.SetupError): s.install_caddy(server,log=lambda _:None,opener=lambda *a,**k:io.BytesIO(raw))
        self.assertFalse((server/'tools/caddy/caddy.exe').exists())
        with patch.object(s,'CADDY_SHA256',hashlib.sha256(raw).hexdigest()):
            self.assertTrue(s.install_caddy(server,log=lambda _:None,opener=lambda *a,**k:io.BytesIO(raw)).exists())
    def test_caddy_network_failure_no_executable(self):
        server=self.root/'server'; server.mkdir()
        def bad(*a,**k): raise OSError('offline')
        with self.assertRaises(OSError): s.install_caddy(server,log=lambda _:None,opener=bad)
        self.assertFalse((server/'tools/caddy/caddy.exe').exists())
    def test_preexisting_stage_preserved(self):
        server=self.root/'server'; folder=server/'tools/caddy'; folder.mkdir(parents=True)
        stage=folder/'caddy.exe.prepared'; stage.write_text('old incomplete file')
        raw=self.archive()
        with patch.object(s,'CADDY_SHA256',hashlib.sha256(raw).hexdigest()):
            with self.assertRaises(FileExistsError): s.install_caddy(server,log=lambda _:None,opener=lambda *a,**k:io.BytesIO(raw))
        self.assertEqual(stage.read_text(),'old incomplete file')

if __name__=='__main__': unittest.main()
