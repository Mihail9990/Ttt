from pathlib import Path
import queue
import sys
import threading
import tkinter as tk
from tkinter import ttk,filedialog,messagebox
from setup_core import install,adopt_existing,prepare_ea,install_caddy
from connectivity_core import profile,ConnectionSession,EXE_SHA256
import hashlib
root=tk.Tk();root.title('RECOVERY — единая подготовка VPS');root.geometry('980x780')
assets=Path(__file__).resolve().parent;payload=assets/'server';events=queue.Queue();busy=[False];ready=[None];session=[None];key=[None]
frame=ttk.Frame(root,padding=14);frame.pack(fill='both',expand=True)
ttk.Label(frame,text='Установка и первое подключение виджета',font=('Segoe UI',15,'bold')).pack(anchor='w')
ttk.Label(frame,text='Без запуска реальной торговли. Python и MT5 установлены вручную.\nУкажите пути, официальный Caddy ZIP и публичный IP вашего VPS.',justify='left').pack(anchor='w',pady=8)
python=tk.StringVar(value=sys.executable);server=tk.StringVar(value=str(Path.home()/'Recovery-Server'));data=tk.StringVar();archive=tk.StringVar();ip=tk.StringVar();url=tk.StringVar()
def choose(var,kind):
    p=filedialog.askdirectory() if kind=='dir' else filedialog.askopenfilename(filetypes=[('ZIP','*.zip')] if kind=='zip' else [('Python','python.exe')])
    if p:var.set(p)
def row(label,var,kind=None):
    f=ttk.Frame(frame);f.pack(fill='x',pady=4);ttk.Label(f,text=label,width=26).pack(side='left');ttk.Entry(f,textvariable=var).pack(side='left',fill='x',expand=True)
    if kind:ttk.Button(f,text='Выбрать',command=lambda:choose(var,kind)).pack(side='right')
row('Python x64:',python,'exe');row('Папка сервера:',server,'dir');row('Каталог данных MT5:',data,'dir');row('Caddy 2.11.9 amd64 ZIP:',archive,'zip');row('Публичный IPv4 VPS:',ip)
ttk.Label(frame,text='Новую папку сервера можно вписать в поле. Для MT5: Файл → Открыть каталог данных.\nЕсли папка MT5 не указана, советник не копируется. Algo Trading не включается.').pack(anchor='w',pady=5)
controls=ttk.Frame(frame);controls.pack(fill='x',pady=8)
status=tk.StringVar(value='После подготовки появятся адрес и ключ для приложения.')
ttk.Label(frame,textvariable=status,wraplength=920,justify='left').pack(anchor='w',pady=5)
credentials=ttk.Frame(frame);credentials.pack(fill='x');ttk.Entry(credentials,textvariable=url,state='readonly').pack(side='left',fill='x',expand=True)
def copy_url():
    if url.get():root.clipboard_clear();root.clipboard_append(url.get())
def copy_key():
    if key[0]:root.clipboard_clear();root.clipboard_append(key[0]);status.set('Ключ скопирован. Вставьте только в приложение, не отправляйте в чат. Общий буфер RDP может синхронизировать ключ.')
ttk.Button(credentials,text='Копировать адрес',command=copy_url).pack(side='left',padx=5)
key_button=ttk.Button(credentials,text='Копировать ключ',command=copy_key,state='disabled');key_button.pack(side='left')
log=tk.Text(frame,height=18,wrap='word');log.pack(fill='both',expand=True,pady=8)
def emit(text):events.put(('log',text))
def prepare():
    if busy[0] or session[0] is not None:return
    values=(python.get().strip(),server.get().strip(),data.get().strip(),archive.get().strip(),ip.get().strip())
    if not values[3]:messagebox.showwarning('Нужен архив','Выберите официальный caddy_2.11.9_windows_amd64.zip.');return
    if not messagebox.askyesno('Подготовить?', 'Будут установлены Python-зависимости из PyPI и проверенный Caddy, а исходник советника скопирован в выбранный MT5.\nСуществующие данные не перезаписываются. Торговля не запускается. Продолжить?'):return
    busy[0]=True;prepare_button.config(state='disabled');connect_button.config(state='disabled')
    def work():
        try:
            py,target,mt5,zipfile,address=values
            from connectivity_core import public_ip
            address=public_ip(address)
            if Path(target).exists():target=adopt_existing(payload,target);emit('Проверена существующая установка, без переустановки.\n')
            else:target=install(payload,target,py,log=emit)
            exe=target/'tools/caddy/caddy.exe'
            if exe.exists():
                if hashlib.sha256(exe.read_bytes()).hexdigest()!=EXE_SHA256:raise RuntimeError('Существующий Caddy отличается от проверенного; не перезаписан.')
                emit('Caddy уже установлен и проверен.\n')
            else:install_caddy(target,log=emit,local_archive=zipfile)
            if mt5:
                dest=Path(mt5)/'MQL5/Experts/RecoveryEvidenceBridge.mq5';src=target/'recovery/mql5/RecoveryEvidenceBridge.mq5'
                if dest.exists() and dest.read_bytes()==src.read_bytes():emit('Исходник EA уже совпадает. Компиляцию/настройки проверьте в MetaEditor.\n')
                else:prepare_ea(target,mt5);emit('Исходник EA скопирован. Его надо скомпилировать и добавить на график вручную; торговля не включена.\n')
            else:emit('Каталог MT5 не выбран: EA НЕ установлен. Для первого подключения виджета он не требуется.\n')
            folder,token=profile(target,address)
            events.put(('ready',(target,folder,token,address)))
        except Exception as exc:events.put(('error',str(exc)))
    threading.Thread(target=work,daemon=False).start()
def connect():
    if busy[0] or ready[0] is None or session[0] is not None:return
    if not messagebox.askyesno('Подключить виджет без торговли?', 'Будут запущены только read-only API на 127.0.0.1:8767 и Caddy на TCP 443. Firewall не меняется.\nIP передаётся Let’s Encrypt и публикуется в CT-журналах для сертификата. Условия: https://letsencrypt.org/repository/\n\nПодтверждаете принадлежность IP вашему VPS и продолжение с этими условиями?'):return
    busy[0]=True;connect_button.config(state='disabled');prepare_button.config(state='disabled')
    def work():
        try:
            target,folder,token,address=ready[0];obj=ConnectionSession(target,assets);obj.start(address,token,folder);session[0]=obj;events.put(('connected',None))
        except Exception as exc:events.put(('error',str(exc)))
    threading.Thread(target=work,daemon=False).start()
def stop():
    if busy[0] or session[0] is None:return
    busy[0]=True;stop_button.config(state='disabled')
    def work():
        try:session[0].stop();session[0]=None;events.put(('stopped',None))
        except Exception as exc:events.put(('error',str(exc)))
    threading.Thread(target=work,daemon=False).start()
prepare_button=ttk.Button(controls,text='1. Подготовить всё',command=prepare);prepare_button.pack(side='left')
connect_button=ttk.Button(controls,text='2. Подключить виджет (без торговли)',command=connect,state='disabled');connect_button.pack(side='left',padx=8)
stop_button=ttk.Button(controls,text='Остановить подключение',command=stop,state='disabled');stop_button.pack(side='left')
def poll():
    while True:
        try:kind,value=events.get_nowait()
        except queue.Empty:break
        if kind=='log':log.insert('end',value);log.see('end');continue
        busy[0]=False
        if kind=='ready':ready[0]=value;key[0]=value[2];url.set('https://'+value[3]);key_button.config(state='normal');connect_button.config(state='normal');status.set('Подготовлено. Нажмите «Подключить виджет», затем вставьте адрес и ключ в обновлённое приложение.')
        elif kind=='connected':stop_button.config(state='normal');status.set('Процессы запущены. Это ещё не подтверждение HTTPS. В приложении нажмите обновление: ожидается «Только чтение: связь с VPS работает». MT5 и торговля не запущены.')
        elif kind=='stopped':connect_button.config(state='normal');prepare_button.config(state='normal');status.set('Подключение остановлено. Ключ и сертификаты сохранены локально.')
        else:status.set('Ошибка: '+value);log.insert('end','Ошибка: '+value+'\n');prepare_button.config(state='normal');connect_button.config(state='normal' if ready[0] else 'disabled')
    if not busy[0] and session[0] is not None and any(c.poll() is not None for c in session[0].children):
        log.insert('end',session[0].logs());log.see('end');status.set('Один процесс завершился; останавливаю только остальные процессы этого подключения.');stop()
    root.after(500,poll)
def close():
    if busy[0] or session[0] is not None:messagebox.showinfo('Сначала остановите','Дождитесь завершения или нажмите «Остановить подключение».')
    else:root.destroy()
root.protocol('WM_DELETE_WINDOW',close);root.after(500,poll);root.mainloop()
