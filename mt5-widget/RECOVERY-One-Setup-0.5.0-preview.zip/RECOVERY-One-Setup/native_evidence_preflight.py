"""Read-only prerequisite attestation on an already initialized terminal.

No trading, initialization, login, shutdown, or permission changes. A fresh
historical SL mailbox response proves the local EA path, not safe future fills.
"""
from datetime import datetime, timezone, timedelta
from decimal import Decimal
from pathlib import Path
from uuid import uuid4
import math
import os
import subprocess
import time

class CheckError(RuntimeError): pass

def verify_mailbox_acl(directory):
    if os.name != 'nt': raise CheckError('Windows required')
    p=Path(directory)
    for item in [p,*p.parents]:
        if item.is_symlink() or (item.exists() and getattr(item.stat(),'st_file_attributes',0)&1024):
            raise CheckError('Mailbox reparse path rejected')
    if not p.is_absolute() or not p.is_dir() or str(p).startswith('\\\\'):
        raise CheckError('Local existing mailbox required')
    # Strict allow-list on EVERY ancestor, including the drive root. Even an
    # allow ACE later narrowed by deny is rejected conservatively. This may fail
    # on normal Windows roots; it never changes their permissions to pass.
    script="""$ErrorActionPreference='Stop'; $p=$env:RECOVERY_CHECK_MAILBOX; $me=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value; $allow=@($me,'S-1-5-18','S-1-5-32-544'); $cursor=Get-Item -LiteralPath $p -Force; while($null -ne $cursor){ if(($cursor.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'Reparse path rejected'}; $a=Get-Acl -LiteralPath $cursor.FullName; $owner=([Security.Principal.NTAccount]$a.Owner).Translate([Security.Principal.SecurityIdentifier]).Value; if($allow -notcontains $owner){throw 'Owner rejected'}; foreach($r in $a.Access){$sid=$r.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value; if($r.AccessControlType -eq 'Allow' -and (([int]$r.FileSystemRights -band 852310) -ne 0) -and $allow -notcontains $sid){throw 'Ancestor writer rejected'}}; $cursor=$cursor.Parent }; Write-Output 'OK'"""
    env=os.environ.copy();env['RECOVERY_CHECK_MAILBOX']=str(p)
    r=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',script],env=env,capture_output=True,text=True,timeout=15,creationflags=subprocess.CREATE_NO_WINDOW)
    if r.returncode or r.stdout.strip()!='OK': raise CheckError('Mailbox and ancestor permissions not verified')



def verify_native_prerequisites(api, *, terminal, account, server, symbol, magic,
        expected_data_path=None, timeout=20.0, _acl_check=None, _bridge_type=None,
        _binding_type=None, _pending_error=None, _clock=time.monotonic,
        _sleep=time.sleep, _now=None):
    """Fail closed unless REAL identity, secure mailbox and fresh EA reply agree.

    Underscored hooks exist for offline doubles only. No cached attestation is
    accepted. Caller owns initialized MT5 session and subsequent execution.
    """
    if type(account) is not int or account <= 0 or type(magic) is not int or magic <= 0:
        raise CheckError('Invalid account or magic')
    if not isinstance(server,str) or not server or not isinstance(symbol,str) or not symbol:
        raise CheckError('Exact server and symbol required')
    terminal=Path(terminal)
    if not terminal.is_absolute() or not terminal.is_file():
        raise CheckError('Existing absolute terminal executable required')
    if isinstance(timeout,bool) or not isinstance(timeout,(int,float)) or not math.isfinite(timeout) or not 0 < timeout <= 60:
        raise CheckError('Invalid timeout')
    if _bridge_type is None:
        from recovery.local_evidence_bridge import LocalEvidenceBridge
        from recovery.ea_stop_evidence import ExitBinding, StopEvidenceUnavailable
        _bridge_type=LocalEvidenceBridge; _binding_type=ExitBinding; _pending_error=StopEvidenceUnavailable
    acl_check=_acl_check or verify_mailbox_acl
    now=_now or datetime.now(timezone.utc)
    lower=now-timedelta(hours=72)
    def canonical(path): return os.path.normcase(os.path.abspath(str(path)))
    def session(expected=None):
        a=api.account_info(); t=api.terminal_info()
        real=getattr(api,'ACCOUNT_TRADE_MODE_REAL',None)
        if (a is None or t is None or type(real) is not int or
            getattr(a,'trade_mode',None)!=real or a.login!=account or
            a.server!=server or not t.connected):
            raise CheckError('REAL account/session mismatch')
        if canonical(t.path)!=canonical(terminal.parent): raise CheckError('Terminal path mismatch')
        data=Path(t.data_path)
        if not data.is_absolute() or (expected is not None and canonical(data)!=canonical(expected)):
            raise CheckError('Data path mismatch')
        if expected_data_path is not None and canonical(data)!=canonical(expected_data_path):
            raise CheckError('Expected data path mismatch')
        return data
    def signature(d):
        return (d.ticket,d.order,d.position_id,d.symbol,d.type,d.entry,d.reason,d.time_msc,str(d.volume))
    data=session(); mailbox=data/'MQL5'/'Files'/'RECOVERY'; acl_check(mailbox); session(data)
    history=api.history_deals_get(lower,now); session(data)
    if history is None: raise CheckError('History unavailable')
    candidates=[d for d in history if d.symbol==symbol and d.entry==api.DEAL_ENTRY_OUT
        and d.reason==api.DEAL_REASON_SL and int(lower.timestamp()*1000)<=d.time_msc<=int(now.timestamp()*1000)]
    if not candidates: raise CheckError('No recent historical SL; evidence cannot be proven without it')
    deal=max(candidates,key=lambda d:(d.time_msc,d.ticket))
    same=[d for d in history if d.ticket==deal.ticket]
    if len(same)!=1: raise CheckError('Duplicate historical exit')
    if deal.type not in (api.DEAL_TYPE_BUY,api.DEAL_TYPE_SELL): raise CheckError('Exit side invalid')
    binding=_binding_type(request_id=uuid4().hex,account=account,server=server,
        deal=int(deal.ticket),order=int(deal.order),position=int(deal.position_id),symbol=symbol,
        exit_side='BUY' if deal.type==api.DEAL_TYPE_BUY else 'SELL',
        time_msc=int(deal.time_msc),volume=Decimal(str(deal.volume)))
    bridge=_bridge_type(mailbox); session(data); bridge.publish(binding)
    deadline=_clock()+timeout
    while _clock()<deadline:
        session(data)
        try: level=bridge.collect(binding)
        except _pending_error:
            _sleep(.25); continue
        if not isinstance(level,Decimal) or not level.is_finite() or level<=0:
            raise CheckError('Invalid SL evidence')
        history=api.history_deals_get(position=int(deal.position_id));session(data)
        current=None if history is None else [d for d in history if d.ticket==deal.ticket]
        if current is None or len(current)!=1 or signature(current[0])!=signature(deal):
            raise CheckError('History changed')
        acl_check(mailbox);session(data)
        return {'ok':True,'mode':'native_prerequisite_read_only','trading':False,
            'evidence_verified':True,'account':account,'server':server,'symbol':symbol,
            'magic':magic,'terminal':str(terminal),'data_path':str(data),
            'evidence_deal':deal.ticket,'verified_at':datetime.now(timezone.utc).isoformat()}
    raise CheckError('EA evidence timeout')
