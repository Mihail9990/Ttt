import json
import subprocess
import threading
import queue
from pathlib import Path
import tkinter as tk
from tkinter import messagebox
root=tk.Tk();root.title('RECOVERY: проверка советника');root.geometry('610x370')
box=tk.Frame(root,padx=18,pady=18);box.pack(fill='both',expand=True)
tk.Label(box,text='Проверка Python ↔ RecoveryEvidenceBridge',font=('Segoe UI',13,'bold')).pack(anchor='w')
tk.Label(box,text='Bybit-Live-6 · XAUUSD.s\nВыбирается последнее закрытие по SL за 72 часа.\nТолько история и файлы запроса/ответа. Без сделок.\nMT5 и советник должны быть открыты. Algo Trading не включайте.',justify='left').pack(anchor='w',pady=10)
tk.Label(box,text='Номер текущего счёта (не пароль):').pack(anchor='w');entry=tk.Entry(box);entry.pack(anchor='w')
status=tk.StringVar(value='Тест не запускает торговый сервис и не меняет его состояние.')
tk.Label(box,textvariable=status,wraplength=560,justify='left').pack(anchor='w',pady=10)
events=queue.Queue();busy=[False]
def start():
    if busy[0]:return
    account=entry.get().strip()
    if not account.isascii() or not account.isdigit() or not 1<=len(account)<=20 or int(account)<=0:
        status.set('Введите номер счёта цифрами.');return
    python=Path.home()/'Recovery-Server'/'.venv-native'/'Scripts'/'python.exe'
    if not python.is_file():status.set('Не найден Python установленного Recovery-Server.');return
    busy[0]=True;button.config(state='disabled');status.set('Проверяю историю, каталог MT5 и ответ советника…')
    def work():
        try:
            r=subprocess.run([str(python),str(Path(__file__).with_name('check_worker.py'))],input=account+'\n',capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=60,creationflags=subprocess.CREATE_NO_WINDOW)
            d=json.loads(r.stdout);events.put(d)
        except Exception:events.put({'ok':False,'reason':'Diagnostic unavailable'})
    threading.Thread(target=work,daemon=True).start()
def poll():
    try:d=events.get_nowait()
    except queue.Empty:root.after(100,poll);return
    busy[0]=False;button.config(state='normal')
    if d.get('ok') is True and d.get('evidence_verified') is True and d.get('trading') is False:
        text='Ответ советника получен и проверен по исторической сделке.\nЭто проверка связи, не готовности реальной торговли.'
    else:
        reason=d.get('reason','')
        hints={'No recent completed SL exit':'За последние 72 часа не найден подходящий выход XAUUSD.s по SL.', 'Mailbox permissions not verified':'Права папки RECOVERY не удалось безопасно проверить.', 'EA response not verified within 20 seconds':'Нет подтверждённого ответа за 20 секунд. Проверьте советник и его журнал Experts.', 'Session mismatch':'Не совпал счёт/сервер либо терминал отключён.', 'Terminal path mismatch':'Подключён другой терминал MT5.'}
        text=hints.get(reason,'Проверка не завершена. Проверьте MT5, путь установки и каталог RECOVERY.')+'\nОрдеров не отправляли.'
    status.set(text);messagebox.showinfo('Результат',text,parent=root);root.after(100,poll)
button=tk.Button(box,text='Проверить советник',command=start);button.pack(anchor='w')
def close():
    if busy[0]:messagebox.showinfo('Подождите','Дождитесь завершения проверки, до 60 секунд.')
    else:root.destroy()
root.protocol('WM_DELETE_WINDOW',close);root.after(100,poll);root.mainloop()
