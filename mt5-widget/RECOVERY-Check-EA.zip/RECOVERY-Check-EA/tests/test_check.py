import unittest
import sys
from types import SimpleNamespace as N
from pathlib import Path
from decimal import Decimal
from datetime import datetime,timezone
sys.path.insert(0,'/workspace/shared/mt5-widget/server')
from recovery.ea_stop_evidence import ExitBinding,StopEvidenceUnavailable
from check_core import check,CheckError
class Fake:
    DEAL_ENTRY_OUT=1;DEAL_REASON_SL=4;DEAL_TYPE_BUY=0;DEAL_TYPE_SELL=1
    def __init__(self):
        self.deal=N(ticket=10,order=11,position_id=12,symbol='XAUUSD.s',type=1,entry=1,reason=4,time_msc=1735689600000,volume=.01);self.closed=False
    def initialize(self,*a,**k):return True
    def account_info(self):return N(login=123,server='Bybit-Live-6')
    def terminal_info(self):return N(connected=True,path='/terminal',data_path='/data')
    def history_deals_get(self,*a,**k):return [self.deal]
    def shutdown(self):self.closed=True
class Bridge:
    def __init__(self,path):pass
    def publish(self,b):self.b=b;assert len(b.request_id)==32
    def collect(self,b):assert b==self.b;return Decimal('4000')
class Tests(unittest.TestCase):
    def runcheck(self,api,**kw):return check(api,123,Path('/terminal/terminal64.exe'),bridge_type=kw.pop('bridge_type',Bridge),binding_type=ExitBinding,pending_error=StopEvidenceUnavailable,acl_check=kw.pop('acl_check',lambda p:None),now=datetime(2025,1,1,tzinfo=timezone.utc),**kw)
    def test_success(self):
        a=Fake();r=self.runcheck(a);self.assertTrue(r['evidence_verified']);self.assertTrue(a.closed);self.assertNotIn('account',r)
    def test_wrong_account(self):
        a=Fake();a.account_info=lambda:N(login=456,server='Bybit-Live-6')
        with self.assertRaises(CheckError):self.runcheck(a)
        self.assertTrue(a.closed)
    def test_no_candidate(self):
        a=Fake();a.deal.reason=0
        with self.assertRaises(CheckError):self.runcheck(a)
    def test_acl_denied_before_publish(self):
        def deny(p):raise CheckError('denied')
        with self.assertRaises(CheckError):self.runcheck(Fake(),acl_check=deny)
    def test_pending_timeout(self):
        class Pending(Bridge):
            def collect(self,b):raise StopEvidenceUnavailable('pending')
        times=iter([0,0,21])
        with self.assertRaises(CheckError):self.runcheck(Fake(),bridge_type=Pending,clock=lambda:next(times),sleep=lambda _:None)
    def test_history_mutation(self):
        a=Fake()
        def hist(*args,**kw):return [] if kw else [a.deal]
        a.history_deals_get=hist
        with self.assertRaises(CheckError):self.runcheck(a)
if __name__=='__main__':unittest.main()
