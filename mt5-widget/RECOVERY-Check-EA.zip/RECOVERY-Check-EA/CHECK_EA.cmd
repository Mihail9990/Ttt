@echo off
setlocal DisableDelayedExpansion
cd /d "%~dp0"
py -3 "%~dp0check_gui.pyw"
if errorlevel 1 pause
