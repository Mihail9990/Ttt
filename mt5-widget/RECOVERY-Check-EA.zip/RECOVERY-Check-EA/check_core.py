"""One completed SL history record → local EA mailbox; no trading calls."""
from datetime import datetime, timezone, timedelta
from decimal import Decimal
from pathlib import Path
from uuid import uuid4
import os
import time
import json
import subprocess

class CheckError(RuntimeError): pass


def verify_mailbox_acl(directory):
    if os.name != 'nt': raise CheckError('Windows required')
    p=Path(directory)
    for item in [p,*p.parents]:
        if item.is_symlink() or (item.exists() and getattr(item.stat(),'st_file_attributes',0)&1024):
            raise CheckError('Mailbox reparse path rejected')
    if not p.is_absolute() or not p.is_dir() or str(p).startswith('\\\\'):
        raise CheckError('Local existing mailbox required')
    script="""$ErrorActionPreference='Stop'; $p=$env:RECOVERY_CHECK_MAILBOX; $a=Get-Acl -LiteralPath $p; $me=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value; $allow=@($me,'S-1-5-18','S-1-5-32-544'); $owner=([Security.Principal.NTAccount]$a.Owner).Translate([Security.Principal.SecurityIdentifier]).Value; if($allow -notcontains $owner){throw 'Owner rejected'}; foreach($r in $a.Access){$sid=$r.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value; if($r.AccessControlType -eq 'Allow' -and (([int]$r.FileSystemRights -band 852310) -ne 0) -and $allow -notcontains $sid){throw 'Writer rejected'}}; Write-Output 'OK'"""
    env=os.environ.copy();env['RECOVERY_CHECK_MAILBOX']=str(p)
    r=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',script],env=env,capture_output=True,text=True,timeout=15,creationflags=subprocess.CREATE_NO_WINDOW)
    if r.returncode or r.stdout.strip()!='OK': raise CheckError('Mailbox permissions not verified')


def check(api, account, terminal, *, bridge_type, binding_type, pending_error,
          acl_check=verify_mailbox_acl, clock=time.monotonic, sleep=time.sleep, now=None):
    if type(account) is not int or account<=0:raise CheckError('Account invalid')
    terminal=Path(terminal); expected_server='Bybit-Live-6'; symbol='XAUUSD.s'
    now=now or datetime.now(timezone.utc)
    def session(expected_data=None):
        a=api.account_info();t=api.terminal_info()
        if a is None or t is None or a.login!=account or a.server!=expected_server or not t.connected:
            raise CheckError('Session mismatch')
        if os.path.normcase(os.path.abspath(t.path))!=os.path.normcase(os.path.abspath(str(terminal.parent))):
            raise CheckError('Terminal path mismatch')
        data=Path(t.data_path)
        if not data.is_absolute() or (expected_data is not None and data!=expected_data):raise CheckError('Data path mismatch')
        return data
    def selected(deals):
        if deals is None:raise CheckError('History unavailable')
        candidates=[d for d in deals if d.symbol==symbol and d.entry==api.DEAL_ENTRY_OUT and d.reason==api.DEAL_REASON_SL
                    and int((now-timedelta(hours=72)).timestamp()*1000)<=d.time_msc<=int(now.timestamp()*1000)]
        if not candidates:raise CheckError('No recent completed SL exit')
        return max(candidates,key=lambda d:(d.time_msc,d.ticket))
    def signature(d):
        return (d.ticket,d.order,d.position_id,d.symbol,d.type,d.entry,d.reason,d.time_msc,str(d.volume))
    try:
        if api.initialize(str(terminal),timeout=10000) is not True:raise CheckError('MT5 unavailable')
        data=session(); mailbox=data/'MQL5'/'Files'/'RECOVERY';acl_check(mailbox)
        deal=selected(api.history_deals_get(now-timedelta(hours=72),now));session(data)
        if deal.type not in (api.DEAL_TYPE_BUY,api.DEAL_TYPE_SELL):raise CheckError('Exit side invalid')
        binding=binding_type(request_id=uuid4().hex,account=account,server=expected_server,
             deal=int(deal.ticket),order=int(deal.order),position=int(deal.position_id),symbol=symbol,
             exit_side='BUY' if deal.type==api.DEAL_TYPE_BUY else 'SELL',time_msc=int(deal.time_msc),volume=Decimal(str(deal.volume)))
        bridge=bridge_type(mailbox);bridge.publish(binding)
        deadline=clock()+20
        while clock()<deadline:
            session(data)
            try: level=bridge.collect(binding)
            except pending_error:
                sleep(.25);continue
            if not level.is_finite() or level<=0:raise CheckError('Invalid stop evidence')
            history=api.history_deals_get(position=int(deal.position_id));session(data)
            current=None if history is None else [d for d in history if d.ticket==deal.ticket]
            if current is None or len(current)!=1 or signature(current[0])!=signature(deal):raise CheckError('History changed')
            return {'ok':True,'mode':'ea_readonly_check','trading':False,'evidence_verified':True}
        raise CheckError('EA response not verified within 20 seconds')
    finally:api.shutdown()
