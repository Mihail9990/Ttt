import json
import sys
from pathlib import Path
from check_core import check, CheckError

def main():
    base=Path.home()/'Recovery-Server'
    try:
        account=int(sys.stdin.readline().strip())
        sys.path.insert(0,str(base))
        import MetaTrader5 as mt5
        from recovery.local_evidence_bridge import LocalEvidenceBridge
        from recovery.ea_stop_evidence import ExitBinding, StopEvidenceUnavailable
        result=check(mt5,account,Path(r'C:\Program Files\MetaTrader 5\terminal64.exe'),bridge_type=LocalEvidenceBridge,binding_type=ExitBinding,pending_error=StopEvidenceUnavailable)
        print(json.dumps(result))
    except CheckError as exc:
        print(json.dumps({'ok':False,'reason':str(exc)}))
    except Exception:
        print(json.dumps({'ok':False,'reason':'Diagnostic unavailable'}))
if __name__=='__main__':main()
