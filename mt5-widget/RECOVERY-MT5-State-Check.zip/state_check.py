"""Read-only status of the installed local service. No raw responses or secrets."""
import base64
from datetime import datetime, timezone
import http.client
import json
import os
from pathlib import Path
import re
from local_profile import dpapi, safe_path

def describe(body, now):
    candidates=[body.get('widget'),body.get('state'),body]
    state=next((v for v in candidates if isinstance(v,dict) and 'snapshot' in v),body)
    mode=state.get('mode')
    if mode != 'native':
        return ['STATUS=NOT_NATIVE']
    snap=state.get('snapshot') or {}
    if snap.get('status')=='unavailable':
        return ['STATUS=MT5_SNAPSHOT_UNAVAILABLE']
    if snap.get('status')!='fresh':
        return ['STATUS=INVALID_SNAPSHOT']
    stamp=datetime.fromisoformat(snap['observed_at'].replace('Z','+00:00'))
    age=(now-stamp).total_seconds()
    return ['STATUS='+('MT5_FRESH_ON_VPS' if 0 <= age <= 15 else 'MT5_STALE_ON_VPS'),
            'VPS_UTC='+now.strftime('%Y-%m-%d %H:%M:%S'),
            'SNAPSHOT_UTC='+stamp.astimezone(timezone.utc).strftime('%Y-%m-%d %H:%M:%S'),
            'AGE_MS='+str(round(age*1000))]

def main():
    print('RECOVERY / MT5 STATE / READ ONLY')
    if os.name!='nt':
        print('STATUS=WINDOWS_REQUIRED')
        return
    try:
        p=safe_path(Path.home()/'Recovery-Server'/'connectivity-only'/'profile.json')
        profile=json.loads(p.read_text(encoding='utf-8'))
        token=dpapi(base64.b64decode(profile['key_dpapi'],validate=True),decrypt=True).decode('ascii')
        if not re.fullmatch(r'[A-Za-z0-9_-]{32,128}',token):
            raise ValueError('invalid local key')
    except Exception:
        print('STATUS=LOCAL_PROFILE_NOT_READABLE')
        return
    conn=http.client.HTTPConnection('127.0.0.1',8767,timeout=10)
    try:
        conn.request('GET','/api/recovery/state',headers={'Authorization':'Bearer '+token})
        response=conn.getresponse()
        if response.status!=200:
            print('STATUS=LOCAL_HTTP_'+str(response.status))
            return
        raw=response.read(1000001)
        if len(raw)>1000000:
            print('STATUS=RESPONSE_TOO_LARGE')
            return
        for line in describe(json.loads(raw),datetime.now(timezone.utc)):
            print(line)
    except (OSError,http.client.HTTPException):
        print('STATUS=LOCAL_SERVICE_UNAVAILABLE')
    except (ValueError,AttributeError,KeyError,TypeError):
        print('STATUS=INVALID_RESPONSE')
    finally:
        conn.close()

if __name__=='__main__':
    main()
