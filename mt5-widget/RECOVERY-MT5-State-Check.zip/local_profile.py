import ctypes
import os
from pathlib import Path

class ConnectionError(RuntimeError): pass

def safe_path(path):
    path=Path(path)
    for p in [path,*path.parents]:
        if p.is_symlink() or (p.exists() and getattr(p.stat(),'st_file_attributes',0)&1024):raise ConnectionError('Ссылки/junction не поддерживаются.')
    return path

def dpapi(data,decrypt=False):
    if os.name!='nt':raise ConnectionError('DPAPI доступен только на Windows.')
    from ctypes import wintypes
    class Blob(ctypes.Structure):_fields_=[('size',wintypes.DWORD),('data',ctypes.POINTER(ctypes.c_ubyte))]
    buf=ctypes.create_string_buffer(data);src=Blob(len(data),ctypes.cast(buf,ctypes.POINTER(ctypes.c_ubyte)));dst=Blob()
    crypt=ctypes.WinDLL('crypt32',use_last_error=True);kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.LocalFree.argtypes=[ctypes.c_void_p];kernel.LocalFree.restype=ctypes.c_void_p
    if decrypt:
        fn=crypt.CryptUnprotectData;fn.argtypes=[ctypes.POINTER(Blob),ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(Blob)]
        args=(ctypes.byref(src),None,None,None,None,1,ctypes.byref(dst))
    else:
        fn=crypt.CryptProtectData;fn.argtypes=[ctypes.POINTER(Blob),wintypes.LPCWSTR,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(Blob)]
        args=(ctypes.byref(src),'RECOVERY connectivity only',None,None,None,1,ctypes.byref(dst))
    fn.restype=wintypes.BOOL
    if not fn(*args):raise ConnectionError('Не удалось обработать ключ DPAPI.')
    try:return ctypes.string_at(dst.data,dst.size)
    finally:kernel.LocalFree(ctypes.cast(dst.data,ctypes.c_void_p))

