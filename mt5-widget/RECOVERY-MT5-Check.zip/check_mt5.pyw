import json
from pathlib import Path
import subprocess
import threading
import tkinter as tk
from tkinter import messagebox

base = Path.home() / 'Recovery-Server'
terminal = Path(r'C:\Program Files\MetaTrader 5\terminal64.exe')
diagnostic = base / 'run_recovery_diagnostics.py'
python = base / '.venv-native' / 'Scripts' / 'python.exe'
root = tk.Tk()
root.title('RECOVERY: проверка MT5')
root.geometry('500x295')
box = tk.Frame(root, padx=20, pady=20)
box.pack(fill='both', expand=True)
tk.Label(box, text='Проверка Python → MT5', font=('Segoe UI', 15, 'bold')).pack(anchor='w')
tk.Label(box, text='Bybit-Live-6 · XAUUSD.s\nТолько чтение, без отправки ордеров.', justify='left').pack(anchor='w', pady=(5, 12))
tk.Label(box, text='Номер счёта из заголовка MT5 (не пароль):').pack(anchor='w')
entry = tk.Entry(box, width=23)
entry.pack(anchor='w', pady=5)
status = tk.StringVar(value='Оставь MT5 открытым, а Algo Trading выключенным.')
tk.Label(box, textvariable=status, wraplength=450, justify='left').pack(anchor='w', pady=8)
result = []


def poll():
    if not result:
        root.after(100, poll)
        return
    ok, text = result.pop()
    status.set(text)
    button.config(state='normal')
    if ok:
        messagebox.showinfo('Проверка MT5', text, parent=root)
    else:
        messagebox.showwarning('Проверка MT5', text, parent=root)


def worker(account):
    try:
        run = subprocess.run(
            [str(python), str(diagnostic), '--connect-read-only', '--terminal', str(terminal),
             '--account', account, '--server', 'Bybit-Live-6', '--symbol', 'XAUUSD.s'],
            cwd=base, capture_output=True, encoding='utf-8', errors='replace', timeout=35,
            creationflags=subprocess.CREATE_NO_WINDOW,
        )
        if run.returncode:
            try:
                error = json.loads(run.stderr).get('error_type', '')
            except (ValueError, AttributeError):
                error = ''
            hint = {'RuntimeError': 'Проверь, что MT5 открыт и подключён.',
                    'ValueError': 'Проверь номер счёта, сервер и наличие котировок.'}.get(error, '')
            result.append((False, f'Проверка не прошла (код {run.returncode}). {hint}'))
            return
        data = json.loads(run.stdout)
        if not (data.get('account_match') is True and data.get('quote_available') is True
                and data.get('live_trading') is False and data.get('symbol') == 'XAUUSD.s'):
            raise ValueError
        result.append((True, 'Python → MT5: подключение работает.\nСчёт совпал, котировки и история читаются.\nОрдеров не отправляли. Связь с советником этим тестом не проверена.'))
    except subprocess.TimeoutExpired:
        result.append((False, 'MT5 не ответил за 35 секунд.'))
    except (OSError, ValueError, AttributeError):
        result.append((False, 'Не удалось запустить диагностику или прочитать результат.'))


def start():
    if str(button['state']) == 'disabled':
        return
    account = entry.get().strip()
    if not account.isascii() or not account.isdigit() or not 1 <= len(account) <= 20 or int(account) <= 0:
        status.set('Введи номер счёта: только цифры.')
        return
    for path in (terminal, diagnostic, python):
        if not path.is_file():
            status.set('Не найден файл: ' + str(path))
            return
    button.config(state='disabled')
    status.set('Проверяю подключение…')
    threading.Thread(target=worker, args=(account,), daemon=True).start()
    root.after(100, poll)

button = tk.Button(box, text='Проверить подключение', command=start, padx=12, pady=3)
button.pack(anchor='w')
entry.focus_set()
root.bind('<Return>', lambda event: start())
root.mainloop()
