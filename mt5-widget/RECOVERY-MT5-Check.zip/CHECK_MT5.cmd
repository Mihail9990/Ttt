@echo off
setlocal
set "PY=%USERPROFILE%\Recovery-Server\.venv-native\Scripts\pythonw.exe"
if not exist "%PY%" (
  echo Recovery-Server Python environment not found.
  pause
  exit /b 1
)
start "" "%PY%" "%~dp0check_mt5.pyw"
